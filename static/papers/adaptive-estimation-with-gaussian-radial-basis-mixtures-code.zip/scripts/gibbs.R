source("em.R")

#### Gibbs sampling of Gaussian mixure posterior ####

quants <- function(X, Z, k, sigma=1) {
  n <- nrow(X); d <- ncol(X)
  ns <- rep(0, k)
  means <- matrix(0, nrow=k, ncol=d)
  for(i in 1:n) {
    j <- Z[i]
    ns[j] <- ns[j] + 1
    means[j, ] <- means[j, ] + X[i, ]
  }
  for(j in 1:k) {
    if(ns[j] == 0) {
      means[j, ] <- X[sample.int(n, 1), ]
    } else means[j, ] <- means[j, ]/ns[j]
  }
  return(list(ns=ns, means=means))
}

drawMu <- function(X, Z, k, t, sigma=1, q=list(ns=NA, means=NA)) {
  d <- ncol(X)
  if(is.na(q$ns[1])) q <- quants(X, Z, k, sigma)
  draw <- matrix(NA, nrow=k, ncol=d)
  for(j in 1:k) {
    if(q$ns[j]==0) q$ns[j] <- 1
    draw[j, ] <- rnorm(d, t*q$ns[j]/(1+t*q$ns[j])*q$means[j, ], sigma/sqrt(1+t*q$ns[j]))
  }
  return(draw)
}

drawZ <- function(X, mu, t, sigma=1) {
  n <- nrow(X); d <- ncol(X); k <- nrow(mu)
  Z <- rep(NA, n)
  for(i in 1:n) {
    w <- rep(NA, k)
    for(j in 1:k) {
      w[j] <- exp(-t*sqnorm(X[i, ] - mu[j, ])/(2*sigma^2))
    }
    if(max(w)==0) w <- rep(1, k)
    Z[i] <- sample.int(k, 1, prob=w)
  }
  return(Z)
}

Gibbs <- function(X, k, sigma=1, steps=500, anneal=F) {
  n <- nrow(X); d <- ncol(X)
  # Initialize uniformly
  Z <- rep(NA, n)
  for(i in 1:n) {
    Z[i] <- sample.int(k, 1)
  }
  t <- rep(1, steps)
  if(anneal) t <- seq(0, 1, length.out=steps+1)[-1]
  for(z in 1:steps) {
    mu <- drawMu(X, Z, k, t[z], sigma)
    Z <- drawZ(X, mu, t[z], sigma)
  }
  return(mu)
}
