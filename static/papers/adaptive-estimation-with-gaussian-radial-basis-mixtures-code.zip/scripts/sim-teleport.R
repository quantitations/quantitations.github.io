source("teleport.R")

# data will have
n <- 100
d <- 12
# model is GRBM with
k <- 8
sigma <- 1

R <- 20

print("teleport")
results <- matrix(NA, nrow=R, ncol=3)
colnames(results) <- c("teleport 2500", "teleport 4000", "teleport 5000")
for(i in 1:R) {
  print(i)
  set.seed(i)
  X <- draw(n, d)
  
  set.seed(i)
  results[i, 1] <- max.ll.teleport(X, k, 2500, h=.01)$ll

  set.seed(i)
  results[i, 2] <- max.ll.teleport(X, k, 4000, h=.02)$ll

  set.seed(i)
  results[i, 3] <- max.ll.teleport(X, k, 5000, h=.05, Tsteps=5)$ll
}
write.csv(results, file="teleport.csv", row.names=F)
