source("third-moment.R")

# data will have
n <- 100
d <- 12
# model is GRBM with
k <- 8
sigma <- 1

R <- 20

print("third-moment")
results <- matrix(NA, nrow=R, ncol=2)
colnames(results) <- c("keigen", "tpower")
for(i in 1:R) {
  print(i)
  set.seed(i)
  X <- draw(n, d)
  
  set.seed(i)
  res <- max.ll.mm(X, k, 6000)
  results[i, 1] <- res$ll
  #plot(X, main=paste("first k eigenvecs, LL =", signif(res$ll, 3)))
  #points(res$mu, col=2:(k+1), pch="*", cex=3)
  
  set.seed(i)
  res <- max.ll.mm(X, k, 6000, tpower=T)
  results[i, 2] <- res$ll
  #plot(X, main=paste("tensor power, LL =", signif(res$ll, 3)))
  #points(res$mu, col=2:(k+1), pch="*", cex=3)
}
write.csv(results, file="third-moment.csv", row.names=F)
