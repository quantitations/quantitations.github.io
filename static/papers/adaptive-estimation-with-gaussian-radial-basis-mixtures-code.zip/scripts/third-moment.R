source("em.R")

library(MASS)

#### Third moment tensor method for Gaussian mixture estimation ####

positive <- function(v) {
  for(j in 1:length(v)) {
    if(v[j] < 0) v[j] <- 0
  }
  return(v)
}

tensorMult <- function(G, v) {
  # multiply the vector v into the symmetric 3-tensor G
  d <- dim(G)[1]
  M <- matrix(NA, ncol=d, nrow=d)
  for(j in 1:d) {
    M[j, ] <- G[j, , ] %*% v
  }
  return(M)
}

orthog <- function(M) {
  # draw a random unit vector orthogonal to the columns of M
  d <- nrow(M)
  u <- rnorm(d)
  u <- u - M %*% ginv(t(M) %*% M) %*% t(M) %*% u
  return(u/sqrt(sum(u^2)))
}

MMpoweriter <- function(v, Gamma, W, prec=2, remaining=10) {
  v2 <- W %*% tensorMult(Gamma, t(W) %*% v) %*% t(W) %*% v
  v2 <- v2/sqrt(sum(v2^2))
  # If converged, return v2, otherwise keep iterating
  if(remaining==0) return(v2)
  if(sum(v*v2) >= 1-10^(-prec)) return(v2)
  return(MMpoweriter(v2, Gamma, W, remaining=remaining-1))
}

MMpower <- function(Gamma, W, W.inv, k) {
  d <- ncol(W)
  v <- rnorm(d); v <- v/sqrt(sum(v^2))
  U <- MMpoweriter(v, Gamma, W)
  if(k==1) return(t(W.inv %*% U))
  for(j in 2:k) {
    v <- orthog(U)
    U <- cbind(U, MMpoweriter(v, Gamma, W))
  }
  return(t(W.inv %*% U))
}

MMfirstk <- function(Gamma, W, W.inv, k) {
  # random reference vector
  v <- rnorm(d); v <- v/sqrt(sum(v^2))
  Gv <- W %*% tensorMult(Gamma, t(W) %*% v) %*% t(W)
  e1 <- eigen(Gv)
  U <- e1$vectors[, 1:k]
  for(j in 1:k) {
    # u <- W %*% tensorMult(Gamma, U[, j]) %*% t(W) %*% U[, j]
    # U[, j] <- u/sqrt(sum(u^2))
    U[, j] <- sign(e1$values[j]*sum(v*U[, j])) * U[, j]
  }
  return(t(W.inv %*% U))
}

MMinit <- function(X, k, sigma=1) {
  d <- ncol(X)
  if(k > d) stop("Error: Number of components cannot be greater than dimension.")
  Psi <- k*((t(X) %*% X)/n - sigma^2*diag(d))
  e <- eigen(Psi)
  z <- 1/sqrt(positive(e$values)); z[z==Inf] <- 0
  W <- diag(z) %*% t(e$vectors)
  z <- 1/z; z[z==Inf] <- 0
  W.inv <- e$vectors %*% diag(z)
  
  # This calculation could be sped up by making use of the symmetries
  # but it would take some careful thinking to write the code
  Gamma <- array(NA, dim=c(d, d, d))
  for(x in 1:d) {
    mx <- mean(X[, x])
    for(y in 1:d) {
      my <- mean(X[, y])
      for(z in 1:d) {
        mz <- mean(X[, z])
        s <- 0
        for(i in 1:n) {
          s <- s + X[i, x]*X[i, y]*X[i, z]
        }
        Gamma[x, y, z] <- k*(s/n - sigma^2*(mz*(x==y) + my*(x==z) + mx*(y==z)))
      }
    }
  }
  return(list(Gamma=Gamma, W=W, W.inv=W.inv))
}

max.ll.mm <- function(X, k, m=100, tpower=F) {
  d <- ncol(X)
  M <- MMinit(X, k)
  ll <- -Inf
  mu <- matrix(NA, nrow=k, ncol=d)
  if(tpower) {
    for(j in 1:m) {
      em <- list(ll=-Inf)
      try(em <- EM(X, MMpower(M$Gamma, M$W, M$W.inv, k=k)))
      if(em$ll > ll) {
        ll <- em$ll
        mu <- em$mu
      }
    }
  } else {
    for(j in 1:m) {
      em <- list(ll=-Inf)
      try(em <- EM(X, MMfirstk(M$Gamma, M$W, M$W.inv, k=k)))
      if(em$ll > ll) {
        ll <- em$ll
        mu <- em$mu
      }
    }
  }
  return(list(mu=mu, ll=ll))
}
