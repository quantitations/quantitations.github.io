source("gibbs.R")

#### Teleport annealing with Gibbs steps for Gaussian mixture posterior sampling ####

TeleportAnnealing <- function(X, k, sigma=1, m=10000, h=.01, Tsteps=5, Msteps=1) {
  n <- nrow(X); d <- ncol(X)
  
  # Draw initial labelings uniformly at random
  Z <- matrix(NA, nrow=m, ncol=n)
  for(p in 1:m) {
    for(i in 1:n) {
      Z[p, i] <- sample.int(k, 1)
    }
  }
  
  means <- array(NA, c(m, k, d))
  ns <- matrix(NA, nrow=m, ncol=k)
  
  t <- 0
  while(t < 1) {
    a <- rep(0, m)
    for(p in 1:m) {
      q <- quants(X, Z[p, ], k, sigma)
      ns[p, ] <- q$ns
      means[p, , ] <- q$means
      # the following term of delta doesn't depend on t
      for(i in 1:n) {
        a[p] <- a[p] + sqnorm(X[i, ] - q$means[Z[p, i]])/sigma^2
      }
    }
    assignments <- 1:m
    
    sqns <- matrix(NA, nrow=m, ncol=k)
    for(p in 1:m) {
      for(j in 1:k) {
        sqns[p, j] <- sqnorm(means[p, j, ])
      }
    }
    
    for(i in 1:Tsteps) {
      # Calculate deltas
      delta <- a[assignments]
      for(p in 1:m) {
        for(j in 1:k) {
          delta[p] <- delta[p] + ns[assignments[p], j]*sqns[assignments[p], j]/(sigma^2*(1+t*ns[assignments[p], j])^2) + d*ns[assignments[p], j]/(1+t*ns[assignments[p], j])
        }
      }
      delta <- -delta/2
      delta <- delta - mean(delta)
      
      # Set h
      h.new <- min(h, 1-t)
      
      # Perform teleportations
      B <- (runif(m) > .5 + h.new*delta)
      assignments.new <- assignments
      for(p in 1:m) {
        if(B[p]) {
          assignments.new[p] <- assignments[sample((1:m)[-p], 1)]
        }
      }
      assignments <- assignments.new
      t <- t + h.new
      if(t == 1) break
    }
    
    # Run Gibbs sampling steps
    mu <- array(NA, c(m, k, d))
    for(p in 1:m) {
      mu[p, , ] <- drawMu(X, Z[assignments[p], ], k, t, sigma, q=list(ns=ns[assignments[p], ], means=means[assignments[p], , ]))
      Z[p, ] <- drawZ(X, mu[p, , ], t, sigma)
    }
    if (Msteps <= 1) next
    for(z in 2:Msteps) {
      mu[p, , ] <- drawMu(X, Z[p, , ], k, t, sigma)
      Z[p, ] <- drawZ(X, mu[p, , ], t, sigma)
    }
  }
  return(mu)
}


max.ll.teleport <- function(X, k, m=1000, ...) {
  mus <- TeleportAnnealing(X=X, k=k, m=m, ...)
  ll <- -Inf
  mu <- matrix(NA, nrow=k, ncol=d)
  for(j in 1:m) {
    em <- list(ll=-Inf)
    try(em <- EM(X, mus[j, , ]))
    if(em$ll > ll) {
      ll <- em$ll
      mu <- em$mu
    }
  }
  return(list(mu=mu, ll=ll))
}
