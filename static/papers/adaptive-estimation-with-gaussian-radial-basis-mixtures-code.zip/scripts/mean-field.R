source("em.R")

#### Mean field variational Bayes algorithm for Gaussian mixture posterior ####

MF <- function(X, mu, sigma=1, prec=2, ns=NA) {
  n <- nrow(X); d <- ncol(X); k <- nrow(mu); s <- 2*sigma^2
  if(is.na(ns[1])) ns <- rep(n/k, k)
  
  # Calculate matrix of responsibilities
  lr <- matrix(NA, nrow=n, ncol=k)
  a <- 1/(2*(ns+1))
  for(i in 1:n) {
    for(j in 1:k) {
      lr[i, j] <- -sqnorm(X[i, ] - mu[j, ])/s + a[j]
    }
    lr[i, ] <- lr[i, ] - max(lr[i, ])
  }
  r <- exp(lr)
  for(i in 1:n) {
    r[i, ] <- r[i, ]/sum(r[i, ])
  }
  
  # Calculate new means
  new <- mu
  for(j in 1:k) {
    ns[j] <- sum(r[, j])
    if(ns[j] > 0) new[j, ] <- t(X) %*% r[, j] / (ns[j] + 1)
  }
  
  # Repeat until convergence
  if(max(apply(new - mu, 1, sqnorm)) < sigma*10^(-prec)) return(new)
  return(MF(X, new, sigma, prec, ns))
}

max.ll.mf <- function(X, k=1, m=1000, ...) {
  ll <- -Inf
  mu <- matrix(NA, nrow=k, ncol=d)
  for(j in 1:m) {
    em <- list(ll=-Inf)
    try(em <- EM(X, MF(X, GaussianInitial(X, k, ...))))
    if(em$ll > ll) {
      ll <- em$ll
      mu <- em$mu
    }
  }
  return(list(mu=mu, ll=ll))
}
