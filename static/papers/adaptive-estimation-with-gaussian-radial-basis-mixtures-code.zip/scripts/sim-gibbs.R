source("gibbs.R")

# data will have
n <- 100
d <- 12
# model is GRBM with
k <- 8
sigma <- 1

R <- 20

print("gibbs")
results <- matrix(NA, nrow=R, ncol=10)
colnames(results) <- c("gibbs 1000", "gibbs.a 1000", "gibbs 2000", "gibbs.a 2000", "gibbs 3000", "gibbs.a 3000", "gibbs 4000", "gibbs.a 4000", "gibbs 5000", "gibbs.a 5000")
for(i in 1:m) {
  print(i)
  set.seed(i)
  X <- draw(n, d)
  
  set.seed(i)
  results[i, 1] <- max.ll(X, k, 1000, Gibbs, steps=75)$ll

  set.seed(i)
  results[i, 2] <- max.ll(X, k, 1000, Gibbs, steps=75, anneal=T)$ll

  set.seed(i)
  results[i, 3] <- max.ll(X, k, 2000, Gibbs, steps=30)$ll

  set.seed(i)
  results[i, 4] <- max.ll(X, k, 2000, Gibbs, steps=30, anneal=T)$ll

  set.seed(i)
  results[i, 5] <- max.ll(X, k, 3000, Gibbs, steps=15)$ll

  set.seed(i)
  results[i, 6] <- max.ll(X, k, 3000, Gibbs, steps=15, anneal=T)$ll
  
  set.seed(i)
  results[i, 7] <- max.ll(X, k, 4000, Gibbs, steps=10)$ll

  set.seed(i)
  results[i, 8] <- max.ll(X, k, 4000, Gibbs, steps=10, anneal=T)$ll
  
  set.seed(i)
  results[i, 9] <- max.ll(X, k, 5000, Gibbs, steps=3)$ll

  set.seed(i)
  results[i, 10] <- max.ll(X, k, 5000, Gibbs, steps=3, anneal=T)$ll
}
write.csv(results, file="gibbs.csv", row.names=F)
