source("em.R")

# data will have
n <- 100
d <- 12
# model is GRBM with
k <- 8
sigma <- 1

R <- 20
m <- 6250

print("simple")
results <- matrix(NA, nrow=R, ncol=10)
colnames(results) <- c("select", "gaussian .5", "gaussian 1", "gaussian 2", "gaussian 4", "gaussian 8", "gaussian 12", "gaussian 16", "gaussian 20", "gaussian 24")
for(i in 1:R) {
  print(i)
  set.seed(i)
  X <- draw(n, d)
  Xbar <- apply(X, 2, mean)
  sdev <- apply(X, 2, sd)
  
  set.seed(i)
  results[i, 1] <- max.ll(X, k, m, SelectInitial)$ll

  set.seed(i)
  results[i, 2] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=.5*sdev)$ll

  set.seed(i)
  results[i, 3] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=1*sdev)$ll
  
  set.seed(i)
  results[i, 4] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=2*sdev)$ll
  
  set.seed(i)
  results[i, 5] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=4*sdev)$ll
  
  set.seed(i)
  results[i, 6] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=8*sdev)$ll
  
  set.seed(i)
  results[i, 7] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=12*sdev)$ll
  
  set.seed(i)
  results[i, 8] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=16*sdev)$ll
  
  set.seed(i)
  results[i, 9] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=20*sdev)$ll
  
  set.seed(i)
  results[i, 10] <- max.ll(X, k, m, GaussianInitial, mu=Xbar, scale=24*sdev)$ll
}
write.csv(results, file="simple.csv", row.names=F)
