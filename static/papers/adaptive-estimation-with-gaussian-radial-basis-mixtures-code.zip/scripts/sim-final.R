#### Compare initializers ####

# - simple Gaussian
# - mean field
# - third moment tensor power iterations
# - k-means
# - Gibbs sampling
# - teleport annealing

# (generate 100 new distributions and data sets)


source("teleport.R")
source("third-moment.R")
source("mean-field.R")

max.ll.kmeans <- function(X, k, m=1000) {
  ll <- -Inf
  mu <- matrix(NA, nrow=k, ncol=d)
  for(i in 1:m) {
    em <- list(ll=-Inf)
    try(em <- EM(X, kmeans(X, k)$centers))
    if(em$ll > ll) {
      ll <- em$ll
      mu <- em$mu
    }
  }
  return(list(mu=mu, ll=ll))
}


# data will have
n <- 100
d <- 12
# model is GRBM with
k <- 8
sigma <- 1

R <- 119
results <- matrix(NA, nrow=R, ncol=6)
colnames(results) <- c("simple", "mean field", "third moment", "k-means", "gibbs", "teleport")
for(i in 1:R) {
  print(i)
  set.seed(100+i)
  X <- draw(n, d)

  Xbar <- apply(X, 2, mean)
  sdev <- apply(X, 2, sd)
  
  # Simple initializations
  set.seed(i)
  results[i, 1] <- max.ll(X, k, 6250, GaussianInitial, mu=Xbar, scale=2*sdev)$ll
  
  # Mean field initializations
  set.seed(i)
  results[i, 2] <- max.ll.mf(X, k, 4500, mu=Xbar, scale=2*sdev)$ll

  # Method of moments initializations
  set.seed(i)
  results[i, 3] <- max.ll.mm(X, k, 6000, tpower=T)$ll

  # k-means initializations
  set.seed(i)
  results[i, 4] <- max.ll.kmeans(X, k, 20000)$ll

  # Gibbs sampling initializations
  set.seed(i)
  results[i, 5] <- max.ll(X, k, 5000, Gibbs, steps=3)$ll
  
  # Teleport annealing initializations
  set.seed(i)
  results[i, 6] <- max.ll.teleport(X, k, 5000, h=.05, Tsteps=5)$ll
}
write.csv(results, file="final.csv", row.names=F)
