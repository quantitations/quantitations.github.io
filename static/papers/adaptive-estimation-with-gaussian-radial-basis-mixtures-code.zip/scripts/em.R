#### EM algorithm and utility functions for Gaussian mixture estimation

#### Generate a random distribution to draw a sample from ####

draw <- function(n, d) {
  # Generate a random mixture of Gaussian radial basis functions
  # First generate the number of means from Poisson(100)
  K <- rpois(1, 100)
  # Then generate weights
  W <- rexp(K)
  # Then generate those means from a standard normal
  Mu <- matrix(rnorm(K*d), nrow=K, ncol=d)
  # Then generate standard deviations for these components
  R <- rexp(1); V <- rexp(K, R)
  
  # Draw a sample from that distribution
  X <- matrix(NA, nrow=n, ncol=d)
  for(i in 1:n) {
    j <- sample.int(K, 1, prob=W)
    X[i, ] <- Mu[j, ] + V[j]*rnorm(d)
  }
  return(X)
}


drawGRBM <- function(n, d, k, sigma=1, scale=3) {
  # Generate means from a spherical normal
  Mu <- matrix(scale*rnorm(k*d), nrow=k, ncol=d)
  
  # Draw a sample from that distribution
  X <- matrix(NA, nrow=n, ncol=d)
  for(i in 1:n) {
    j <- sample.int(k, 1)
    X[i, ] <- Mu[j, ] + sigma*rnorm(d)
  }
  return(list(X=X, Mu=Mu))
}



#### The EM algorithm ####

sqnorm <- function(v) {
  return(sum(v^2))
}

EM <- function(X, mu, sigma=1, prec=2) {
  n <- nrow(X); d <- ncol(X); k <- nrow(mu); s <- 2*sigma^2
  
  # Calculate matrix of responsibilities
  lr <- matrix(NA, nrow=n, ncol=k)
  for(i in 1:n) {
    for(j in 1:k) {
      lr[i, j] <- -sqnorm(X[i, ] - mu[j, ])/s
    }
  }
  lr.shift <- matrix(NA, nrow=n, ncol=k)
  for(i in 1:n) {
    lr.shift[i, ] <- lr[i, ] - max(lr[i, ])
  }
  r <- exp(lr.shift)
  for(i in 1:n) {
    r[i, ] <- r[i, ]/sum(r[i, ])
  }
  
  # Calculate new means
  new <- mu
  for(j in 1:k) {
    nj <- sum(r[, j])
    if(nj > 0) new[j, ] <- t(X) %*% r[, j] / nj
  }
  
  # Repeat until convergence then return log likelihood (within const)
  if(max(apply(new - mu, 1, sqnorm)) < sigma*10^(-prec)) {
    ll <- sum(log(apply(exp(lr), 1, sum)))
    return(list(mu=new, ll=ll))
  }
  return(EM(X, new, sigma, prec))
}

max.ll <- function(X, k, m=1, alg, ...) {
  ll <- -Inf
  mu <- matrix(NA, nrow=k, ncol=d)
  for(j in 1:m) {
    em <- list(ll=-Inf)
    try(em <- EM(X, alg(X=X, k=k, ...)))
    if(em$ll > ll) {
      ll <- em$ll
      mu <- em$mu
    }
  }
  return(list(mu=mu, ll=ll))
}


#### Initialize by selecting data points ####

SelectInitial <- function(X, k) {
  n <- nrow(X)
  return(X[sample(1:n, k), ])
}


#### Initialize with Gaussian draws ####

GaussianInitial <- function(X, k, d=1, mu=rep(0, d), scale=rep(1, d)) {
  d <- length(mu)
  return(matrix(rep(mu, k), nrow=k, byrow=T) + matrix(scale*rnorm(d*k), nrow=k, byrow=T))
}