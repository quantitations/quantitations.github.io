
r <- read.csv("simple.csv")
r <- r[-c(6, 15, 16, 18), ]
r.means <- apply(r, 1, mean)
r.scales <- apply(r, 1, sd)
for(i in 1:16) {
  r[i, ] <- (r[i, ] - r.means[i])/r.scales[i]
}
boxplot(r)
r <- read.csv("simple.csv")
r <- r[-c(6, 15, 16, 18), 1:5]
r.means <- apply(r, 1, mean)
r.scales <- apply(r, 1, sd)
for(i in 1:16) {
  r[i, ] <- (r[i, ] - r.means[i])/r.scales[i]
}
boxplot(r)
sum(r[, 1] <= r[, 4])/nrow(r)
# Use Gaussian intialization with scale 2


r <- read.csv("gibbs.csv")
r <- r[-c(15, 16, 18), ]
r.means <- apply(r, 1, mean)
r.scales <- apply(r, 1, sd)
for(i in 1:17) {
  r[i, ] <- (r[i, ] - r.means[i])/r.scales[i]
}
boxplot(r)
# Use 5000 Gibbs steps without annealing


r <- read.csv("third-moment.csv")
r <- r[-c(16, 18), ]
sum(r[, 1] <= r[, 2])/nrow(r)
# Use tensor power iterations


r <- read.csv("teleport.csv")
r <- r[-c(16, 18), ]
r.means <- apply(r, 1, mean)
r.scales <- apply(r, 1, sd)
for(i in 1:18) {
  r[i, ] <- (r[i, ] - r.means[i])/r.scales[i]
}
boxplot(r)
# use 5000 chains with teleport annealing


write.csv(results, "final8.csv", row.names=F)

r1 <- read.csv("final1.csv")
r2 <- read.csv("final2.csv")
r3 <- read.csv("final3.csv")
r4 <- read.csv("final4.csv")
r5 <- read.csv("final5.csv")
r6 <- read.csv("final6.csv")
r7 <- read.csv("final7.csv")
r8 <- read.csv("final8.csv")
r9 <- read.csv("final9.csv")
r <- rbind(r1[1:34, ], r2[35:50, ], r3[51:60, ], r4[61:70, ], r5[71:80, ], r6[81:95, ], r7[96:115, ], r8[116:118, ], r9[119, ])
write.csv(r, "final.csv", row.names=F)

r <- read.csv("final.csv")
r <- r[-c(8, 15, 26, 30, 38, 40, 42, 46, 49, 59, 61, 66, 71, 78, 97, 105, 113, 115, 116), ]

r.means <- apply(r, 1, mean)
r.scales <- apply(r, 1, sd)
for(i in 1:100) {
  r[i, ] <- (r[i, ] - r.means[i])/(1+r.scales[i])
}
for(j in 2:6) {
  r[, j] <- r[, j] - r[, 1]
}


spmatrix <- function(dat) {
  z <- ncol(dat)
  name <- colnames(dat)
  lims <- c(min(dat), max(dat))
  mid <- sum(lims)/2
  par(mfrow=c(z, z), mar=c(2, 2, .1, .1))
  for(i in 1:z) {
    for(j in 1:z) {
      if(i == j) {
        d <- density(dat[, i])
        plot(d, main="", xlab="", ylab="", xlim=lims, yaxt="n")
        rug(dat[, i], lwd=.6)
        text(mid, (min(d$y) + max(d$y))/2, name[i], col=i+1, cex=2.5)
      } else {
        plot(dat[, j], dat[, i], main="", xlab="", ylab="", xlim=lims, ylim=lims)
        abline(0, 1, lty=3)
      }
    }
  }
}

names(r) <- c("Gaussian", "mean field", "moments", "k-means", "Gibbs", "teleport")
png("simulations.png", height=600, width=600)
spmatrix(r[, -1])
dev.off()
